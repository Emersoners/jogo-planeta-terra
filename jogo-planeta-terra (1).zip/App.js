
import React, { useState } from "react";

const questions = [
  { "question": "Como ocorreu a formação inicial da Terra a partir da nebulosa solar?", "options": [ "Por condensação de gases frios na órbita de Marte", "Por fragmentação de cometas que colidiram", "Por acreção de partículas e colisões na nebulosa solar", "Por ação de ventos solares sobre asteroides" ], "answer": 2 },
  { "question": "Qual foi o impacto da colisão com o planeta Theia na formação da Lua?", "options": [ "Formou os anéis de Saturno", "Gerou uma atmosfera de oxigênio puro", "Ejetou material que se agrupou e formou a Lua", "Resfriou completamente a superfície terrestre" ], "answer": 2 },
  { "question": "De que maneira a atmosfera primitiva da Terra se desenvolveu e qual era sua composição inicial?", "options": [ "Através da fotossíntese das primeiras plantas, composta por oxigênio e nitrogênio", "Por liberação de gases vulcânicos, composta por metano, amônia e vapor d'água", "Por explosões solares, composta por hidrogênio puro", "Por impactos de meteoros, composta por ozônio e dióxido de carbono" ], "answer": 1 },
  { "question": "Como a água surgiu na Terra e qual foi o papel dos meteoritos nesse processo?", "options": [ "Meteoritos ricos em gelo trouxeram água durante colisões", "Evaporação dos oceanos antigos", "Fotossíntese das cianobactérias", "Formação a partir da decomposição de minerais" ], "answer": 0 },
  { "question": "Quais foram os principais eventos que levaram à formação dos oceanos primitivos?", "options": [ "Resfriamento da Terra e condensação do vapor d'água", "Impacto de asteroides aquáticos", "Reações químicas na atmosfera", "Fusão de glaciares formadores" ], "answer": 0 },
  { "question": "Como a atividade vulcânica influenciou a formação da crosta terrestre?", "options": [ "Gerou gases venenosos que destruíram a crosta", "Formou ilhas de basalto que se expandiram", "Liberou magma que se resfriou, formando as primeiras rochas sólidas", "Causou terremotos que fundiram continentes" ], "answer": 2 },
  { "question": "Quais são as teorias apresentadas sobre o surgimento da vida na Terra?", "options": [ "Panspermia, evolução química e abiogênese", "Fotossíntese e biogênese", "Catástrofes nucleares e abiogênese", "Geração espontânea e biogênese" ], "answer": 0 },
  { "question": "Como a fotossíntese contribui para a transformação da atmosfera terrestre?", "options": [ "Aumentando a concentração de dióxido de carbono", "Removendo hidrogênio da atmosfera", "Liberando oxigênio como subproduto, mudando sua composição", "Criando ozônio diretamente nas algas" ], "answer": 2 },
  { "question": "Quais foram os principais eventos de extinção em massa e como eles afetaram a evolução da vida?", "options": [ "Eliminação de espécies dominantes, abrindo espaço para novas formas de vida", "Aumento da biodiversidade instantânea", "Redução de oxigênio nas calotas polares", "Transformação de peixes em répteis" ], "answer": 0 },
  { "question": "De que maneira a formação dos continentes influenciou o desenvolvimento da biodiversidade?", "options": [ "Impediu a migração de espécies", "Aumentou o isolamento geográfico, promovendo a especiação", "Destruiu habitats marinhos", "Causou a extinção das plantas terrestres" ], "answer": 1 },
  { "question": "Como a formação da Lua influenciou as condições ambientais da Terra?", "options": [ "Gerando marés estáveis e estabilizando a inclinação do eixo terrestre", "Aumentando a gravidade terrestre", "Eliminando tempestades solares", "Criando a primeira camada de ozônio" ], "answer": 0 },
  { "question": "De que forma a presença de água líquida foi crucial para o surgimento da vida?", "options": [ "Facilitou a erosão das rochas", "Permitiu reações químicas essenciais para organismos vivos", "Criou zonas de subdução oceânica", "Formou a camada de ozônio" ], "answer": 1 },
  { "question": "Como os eventos geológicos moldaram a diversidade de habitats no planeta?", "options": [ "Causaram a extinção total da vida terrestre", "Geraram diferentes tipos de solo e relevo", "Uniformizaram o clima global", "Reduziram a biodiversidade" ], "answer": 1 },
  { "question": "Qual é a importância da atmosfera na proteção da vida terrestre?", "options": [ "Filtra radiação solar nociva e mantém temperatura estável", "Produz água potável", "Impediu a formação da camada de ozônio", "Facilita a dispersão de espécies" ], "answer": 0 },
  { "question": "Como a história geológica da Terra pode nos ajudar a entender as mudanças climáticas atuais?", "options": [ "Por meio de fósseis e registros de camadas de gelo", "Apenas com observações modernas", "Analisando a crosta terrestre somente", "Estudando o núcleo externo" ], "answer": 0 },
  { "question": "De que maneira a compreensão da formação da Terra pode influenciar a busca por vida em outros planetas?", "options": [ "Identificando condições semelhantes em exoplanetas", "Descobrindo novos tipos de rochas", "Criando atmosferas artificiais na Terra", "Mudando a órbita da Terra" ], "answer": 0 },
  { "question": "Como os eventos de extinção em massa moldaram a trajetória evolutiva das espécies?", "options": [ "Criaram oportunidades evolutivas para novas espécies", "Eliminando toda forma de vida", "Impedindo a fotossíntese", "Resfriando o núcleo terrestre" ], "answer": 0 },
  { "question": "Quais são as implicações da tectônica de placas na formação de recursos naturais?", "options": [ "Formação de jazidas minerais e petróleo", "Destruição completa de minerais", "Impedimento da formação de rochas", "Criação de oceanos artificiais" ], "answer": 0 },
  { "question": "Como a evolução da atmosfera terrestre está relacionada ao desenvolvimento de diferentes formas de vida?", "options": [ "A presença de oxigênio permitiu o surgimento de organismos complexos", "A ausência de nitrogênio facilitou a fotossíntese", "O excesso de gás carbônico tornou a vida possível", "A eliminação do oxigênio gerou novas espécies" ], "answer": 0 },
  { "question": "De que forma a história da Terra nos ensina sobre a resiliência e adaptação dos seres vivos?", "options": [ "Mostra como a vida sobreviveu a eventos extremos", "Demonstra que toda vida foi extinta várias vezes", "Prova que a evolução é imprevisível", "Afirma que a Terra sempre teve o mesmo clima" ], "answer": 0 }
];

export default function PlanetEarthGame() {
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [name, setName] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (index) => {
    if (index === questions[current].answer) {
      setScore(score + 1);
    }
    const next = current + 1;
    if (next < questions.length) {
      setCurrent(next);
    } else {
      setShowResult(true);
    }
  };

  if (!submitted) {
    return (
      <div className="p-8 max-w-2xl mx-auto text-center">
        <h1 className="text-2xl font-bold mb-4">Digite seu nome para começar</h1>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="border p-2 rounded w-full mb-4"
        />
        <button
          onClick={() => setSubmitted(true)}
          className="bg-green-500 text-white font-bold py-2 px-4 rounded"
        >
          Iniciar Jogo
        </button>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-2xl mx-auto text-center">
      {!showResult ? (
        <div>
          <h1 className="text-xl font-bold mb-4">Pergunta {current + 1} de {questions.length}</h1>
          <h2 className="text-2xl font-semibold mb-6">{questions[current].question}</h2>
          <div className="grid gap-4">
            {questions[current].options.map((option, i) => (
              <button
                key={i}
                className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                onClick={() => handleAnswer(i)}
              >
                {option}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div>
          <h1 className="text-3xl font-bold">Jogo finalizado!</h1>
          <p className="text-xl mt-4">Parabéns, {name}! Você acertou {score} de {questions.length} perguntas.</p>
        </div>
      )}
    </div>
  );
}
